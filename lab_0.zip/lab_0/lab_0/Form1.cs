﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace lab_1
{
    public partial class Form1 : Form
    {
        private Bitmap bitmap;
        private List<List<int>> dots;
        private Color color;
        private Random random = new Random();
        public Form1()
        {
            InitializeComponent();
            bitmap = new Bitmap(pictureBox1.Width, pictureBox1.Height);
            dots = new List<List<int>>();
            color = Color.FromArgb(246, 45, 71);
            Console.WriteLine("Start");
        }

        private void MouseClickEvent(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                List<int> coords = new List<int>();
                coords.Add(e.X);
                coords.Add(e.Y);

                color = Color.FromArgb(0, 0, 0);
                bitmap.SetPixel(e.X, e.Y, color);
                dots.Add(coords);
                pictureBox1.Image = bitmap;
            }
            else if (e.Button == MouseButtons.Right)
            {
                Console.WriteLine("Change color");
                int amount = dots.Count;

                bitmap = new Bitmap(pictureBox1.Width, pictureBox1.Height);
                color = Color.FromArgb(random.Next(0, 255), random.Next(0, 255), random.Next(0, 255));

                foreach (var dot in dots)
                {
                    SetPixel(dot[0], dot[1]);
                }
                pictureBox1.Image = bitmap;
            }
        }

        private void SetPixel(int x, int y)
        {
            bitmap.SetPixel(x, y, color);
        }



    }


}
